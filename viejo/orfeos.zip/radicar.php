<?php

include ("encabezado.php");
include ("nav.php");
include ("dashboard.php");
//include ("pie.php"); // En index.php no incluyo en pie.php porque el dashboard tiene su propio pie de pagina

?>